# 一、概念

  ribbon是实现一套客户端，负载均衡的工具，简单的说，ribbon是一个开源项目，主要提供给客户端软件负载均衡算法和服务调用。

> 负载均衡和服务调用的提供者

  主要用于:

- 负载均衡
  - 本地负载均衡: 会在注册中心上的列表进行负载均衡又称为进程内负载均衡
- 服务调用

# 二、使用

  在我们使用使用，不需要引如Ribbon依赖，因为Eureka已经再使用Ribbon了；、

- Entity: 返回详细的对象
  - 响应信息
  - 响应码...
- Object： 可以直接理解为JSON

![image-20221122230533031](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221122230533031.png)



# 三、负载均衡规则

  Ribbon的默认规则

IRule规则

- 轮询
- 随机
- 重试
- 轮询的扩展，轮询看响应速度
- 过滤故障实例，选择并发量最小的服务
- 默认规则

![image-20221122231207523](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221122231207523.png)

## 1. 规则替换

  注意配置规则！！

***自定义配置类不能放在@ComponetScan所扫描的包和子包下，否则配置会被所有Ribbon客户端共享，达不到特殊定制化的目的***！

1. 修改Order模块
2. 远离ComponetScan创建包
3. 添加MySelfRule规则类
4. 主启动类添加@RibbonClient

![image-20221122232305387](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221122232305387.png)

## 2. 负载均衡轮询

### 原理

  负载均衡算法: **rest接口第几次请求%集群总数=实际调用服务器的位置下标**；

》 等待填坑

