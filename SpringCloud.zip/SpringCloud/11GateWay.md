

  

# 一、概述

![image-20221128152243972](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128152243972.png)

  GateWay是zuul的替代品，由于Zuul2.0迟迟没有出来，SpringCloud社区推出了gateWay网关来替代zuul1.x版本。提供了以下功能: 底层使用netty通讯

- 反向代理
- 鉴权

- 安全
- 监控、指标
- 限流

  GateWay具有以下特征: 基于Spring，PR，SpringBoot构建

- 动态路由
- 集成hystrix断路器功能
- 路径重写
- 请求限流等功能
- 断言和过滤器

## 1. 非阻塞异步模型

​    gateway是基于异步非阻塞模型上进行开发，性能更优秀。

- 阻塞处理模型就是: 当请求进入ServletContainer，它就会为之绑定一个线程，这种模型只适合用于并发不高的情况。Zuul1.x就是基于这么一个阻塞式处理模型。

  Servlet3.1之后有异步非阻塞的支持，webFlux就是基于这么个框架，他的核心就是基于Reactor相关的实现

![image-20221128170458657](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128170458657.png)

## 2. 三大概念

### 路由Route

  路由是构建网关的基本模块，由ID，和目标URI，和一系列断言和过滤器组成，如果断言为True则匹配该路由。

### 断言Predicate

  断言就是Java8中Java.utils.function.Predicate，匹配Http请求中的内容，如果**请求与断言相互匹配**，则进行路由转发到微服务。

### 过滤Filter

  GatewayFilter的实例，使用过滤器，在请求被路由转发之前或者之后对请求进行修改

> beforeFilter doAction afterFilter

1. 客户端向GateWay请求，先通过网关中断言
2. 在进行n层过滤器
3. 最后根据目标uri访问对应的微服务

![image-20221128171206303](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128171206303.png)

> 总结gateway的作用就是路由转发+执行过滤链



# 二、入门配置

## 1. 基础配置

### Yaml方式

1. 建立POM
2. 修改YAML（配置方式1）

  配置路由: 9527

![image-20221128193734136](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128193734136.png)

> 在gateway当中，不需要SpringBoot-web和SpringBoot-actutor

### 编码方式

1. 建立Pom
2. 修改Yaml(进入注册中心)
3. 建立Config

![image-20221128204639962](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128204639962.png)

## 2. 通过微服务实现动态路由

1. 通过修改yaml实现网关负载均衡轮询

![image-20221128205534764](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128205534764.png)



## 3. Predicate使用

​    在官方自带的断言有11种

![image-20221128205942738](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128205942738.png)

  以上各种RoutePredicateFactory都代表了HTTP请求中不同属性值，之间都可以进行组合，并且通过逻辑AND进行断言匹配。

### 3.1 After

  匹配时间: **ZonedDateTime**

![image-20221128211153223](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128211153223.png)

### 3.2 cookie

- 匹配是否有Cookie，若有，匹配成功，否则拒绝访问。
- ![image-20221128213100527](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128213100527.png)

![image-20221128213157753](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128213157753.png)

### 3.2 Header

- 匹配中检测是否有请求头，若有匹配成功，否则拒绝访问。

![image-20221128213331414](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128213331414.png)

![image-20221128213426307](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128213426307.png)

![image-20221128213459763](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128213459763.png)

### 3.3 Method

- 匹配请求方式GETPost等等。

> predicate就是为了实现一组匹配规则，让请求过来找到对应的route进行处理。

---



## 4. Filter

  使用过滤器，可以在路由转发请求前，或者请求后，对请求进行一定的修改，也就是可以修改进入的HTTP请求和返回的HTTP相应，路由过滤器只能指定路由进行使用。

- **生命周期-pre|post**
- **种类-only|global**

根据官网文档，添加配置: 

  简单实例: 

![image-20221128214617627](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128214617627.png)

### 自定义过滤器

![image-20221128215640381](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221128215640381.png)