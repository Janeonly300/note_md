# 一、概述

  Feign是一个声明式的web服务的客户端，Feign就是参考Ribbon添加了注解+接口的绑定器。

- 我们封装一些客户端类来包装对其他服务的依赖调用。
- Feign让我们只需要创建一个接口+注解就能够实现操作。
- Feign集成了Ribbon

> 关于使用就是在接口添加特定注解就可以了。

# 二、使用

## 1. 使用OpenFeign  

@FeignClient

1. 创建Module-引入依赖
2. 修改yaml
3. 在主类当中开启Feign Client
4. 添加客户端类编写调用其他微服务的接口

## 2. 超时控制

   Feign客户端默认智慧等待1秒钟，若超过，则会抛出一个错误，我们可以通过设置来延长超时时间。

![image-20221125235256978](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221125235256978.png)

## 3. 日志打印

  Open Feign的日志级别，越往下输出越多。

- NONE
- BASIC
- HEADERS
- FULL

  创建一个配置类。

![image-20221125235506669](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221125235506669.png)

- 配置需要监控的接口。

![image-20221125235616603](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221125235616603.png)