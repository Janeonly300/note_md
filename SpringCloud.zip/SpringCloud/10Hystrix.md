# 一、概念

  分布式系统面临的问题: 

- 对于负载的分布式体系，有数十个依赖，依赖不可避免的错误。
- 服务会出现雪崩，高可用受到破坏。

  Hystrix就是用于解决分布式系统延迟和容错的开源库。

- 保证在一个依赖出现问题，不会导致整体的服务失败，避免级联故障，以提高分布式系统的弹性
- 如果出现错误，向调用方抛出备选FallBack



## 1. 功能

- 服务降级
- 服务熔断
- 接近实时监控
- 限流
- 隔离

> 停止更新进入维护

## 2. 重要理念

### 服务降级

  服务器出现问题时候，不让客户端持续等待，立刻返回一个友好的提示。**fallback**

- 程序运行异常
- 超时
- 服务熔断触发降级
- 线程池和信号量打满

### 服务熔断

  当访问达到最大访问，直接拒绝访问，然后调用服务降级方法，返回友好提示。

> 降级-熔断-恢复

### 服务限流

  秒杀高并发的操作，严禁一窝蜂过来拥挤，有序进行。 

---



# 二、Hystrix案例

## 1. 服务降级

###  1.1 使用Jemeter压测

### 1.2 添加客户端在访问

  出现客户端相应缓慢，8001同一层次的其他接口被困死，因为在tomcat线程池当中默认只有10个线程。

### 1.3 Hystrix解决

- 超时导致服务器变慢
- 出错(程序运行出错)

解决方案: 

- 对方超时，必须有服务降级
- 对方down机，必须服务降级
- 对方OK，调用者自己出故障，自己处理降级

```@HystrixCommand(fallbackMethod)```

```EnableCirutBreaker```

![image-20221126203230359](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221126203230359.png)

#### 1.3.1 提供端降级

#### 1.3.2 客户端降级

**![image-20221126205554633](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221126205554633.png)**

### 1.4 全局服务降级

### 1.5 究极服务降级





---

## 2. 服务熔断

![image-20221127140608455](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221127140608455.png)

  断路器就是保险丝，熔断: 应对服务雪崩效应的链路保护机制，当检测节点微服务调用响应正常后，**恢复调用链路**。

- 熔点机制通过Hystrix实现
- 监控微服务调用的状况:
  - 5秒20次调用失败，就会启动熔断机制。

熔断是> https://martinfowler.com/bliki/CircuitBreaker.html

![image-20221127135009718](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221127135009718.png)

  ### 熔断原理

- 熔断打开: 请求不再进行调用当前服务
- 熔断关闭: 熔断关闭，不再对服务进行熔断
- 熔断半开: 部分请求根据规则调用当前服务，如果请求成功且符合规则，则关闭熔断

  设计断路器的三个重要参数; **快照时间窗口、请求总数阀值、错误百分比阀值**

- 快照时间窗口: 统计请求和错误数据，默认为10s内
- 请求总数阀值: 在快照时间窗内，必须满足请求总数才有资格熔断，默认为20;
- 错误百分比法制: 当请求总数在快照时间内超过阀值，例如在10s内发生30次调用，有15次失败，则断路器打开。

![image-20221127143228253](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221127143228253.png)

  当熔断开启后，直接调用fallback；





## 3. 服务监控

  Hystrix还提供了一个准实时的调用监控，以报表的方式或者图形化的方式展现给用户。SpringCloud提供了hystrixDashboard的整合，对监控内容转为可视化界面。

![image-20221127144811620](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221127144811620.png)

![image-20221127145338749](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221127145338749.png)