# 一、引入

> Spring Cloud封装了netflix公司的Eureka模块来进行实现服务治理。
>
>   在传统的RPC远程调用框架中，管理每个服务服务之间依赖关系比较复杂，所以需要服务治理，管理服务之间的依赖。可以实现服务注册、调用、负载均衡、容错等技术。

## 1. 服务注册与发现

   

![image-20221110120443400](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221110120443400.png)

![image-20221110120300009](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221110120300009.png)

## 2. Eureka概念

  eureka包含两个不同的组件: Eureka Server和Eureka Client

### Eureka Server

  提供注册服务，各个服务节点可以通过配置启动，会在Eureka Server中注册

### Eureka Client

 是一个Java客户端，简化和Eureka Server的交互，客户端同时具备内置的、是用轮询的负载算法，来检测服务是否还活着。

## 3. Eureka原理

![image-20221111231736685](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221111231736685.png)



# 一、eureka使用

## 1. 单点模式

1. 建立eureka的ServerMoudle

   ![image-20221110173229087](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221110173229087.png)

2. 编写pom文件

   ```xml
   <dependencies>
   
           <dependency>
               <groupId>com.atjinayi</groupId>
               <artifactId>cloud-api-comen</artifactId>
               <version>1.0-SNAPSHOT</version>
           </dependency>
   
           <dependency>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-starter-web</artifactId>
           </dependency>
           <dependency>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-starter-actuator</artifactId>
           </dependency>
   
           <!--eureka注册服务依赖-->
           <dependency>
               <groupId>org.springframework.cloud</groupId>
               <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
               <version>2.2.9.RELEASE</version>
           </dependency>
   
           <dependency>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-devtools</artifactId>
               <scope>runtime</scope>
               <optional>true</optional>
           </dependency>
   
           <dependency>
               <groupId>org.projectlombok</groupId>
               <artifactId>lombok</artifactId>
               <optional>true</optional>
           </dependency>
           <dependency>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-starter-test</artifactId>
               <scope>test</scope>
           </dependency>
       </dependencies>
   ```

   

3. 配置yaml文件

   ```yaml
   server:
     port: 7001
   eureka:
     instance:
       hostname: localhost
     client:
       serviceUrl:
       	#交互依赖该地址
         defaultZone: http://${eureka.instance.hostname}:${server.port}/eureka
        #证明自己是注册中心服务
       registerWithEureka: false
    	# 不进行注册
   	 fetchRegistry: false
   ```
   
   
   
4. 添加注解

    开启eureka服务。

   ![image-20221110173632808](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221110173632808.png)

5. client进行注册

    1. 另外创建一个SpringBoot模块，进行服务注册

    ![image-20221111225230858](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221111225230858.png)

    2. 添加依赖

       ```xml
       <dependency>
                   <groupId>org.springframework.cloud</groupId>
                   <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
                   <version>2.2.9.RELEASE</version>
               </dependency>
       ```

       

    3. 修改yaml文件

       ```yaml
       eureka:
         client:
           register-with-eureka: true
           fetch-registry: true
           service-url:
           	#指定服务端
             defaultZone: http://localhost:7001/eureka
       ```

    4. 开启Eureka客户端

       ![image-20221111225910245](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221111225910245.png)

## 2、集群模式

  远成服务最核心就是高可用，以我们上面的单点案例，是无法实现高可用性。

> 就是将注册服务中心，让其互相注册。互相守望。



1、 修改host文件，添加域名映射本机

2、 创建两个服务注册中心微服务,两个服务实现互相调用

![image-20221111234237970](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221111234237970.png)

```yaml
#服务一
server:
  port: 7001
eureka:
  instance:
    hostname: eureka7001.com
  server:
    responseCacheUpdateIntervalMs: 3000
    responseCacheAutoExpirationInSeconds: 180
    evictionIntervalTimerInMs: 3000
  client:
    serviceUrl:
      defaultZone: http://eureka7002.com:7002/eureka
    healthcheck:
      enabled: true
    registerWithEureka: false
    fetchRegistry: false

# 服务二
server:
  port: 7002
eureka:
  instance:
    hostname: eureka7002.com
  server:
    responseCacheUpdateIntervalMs: 3000
    responseCacheAutoExpirationInSeconds: 180
    evictionIntervalTimerInMs: 3000
  client:
    serviceUrl:
      defaultZone: http://eureka7001.com:7001/eureka
    healthcheck:
      enabled: true
    registerWithEureka: false
    fetchRegistry: false

# 注册集群
server:
  port: 8001
spring:
  application:
    name: cloud-pri-service
  datasource:
    url: jdbc:mysql://localhost:3306/springcloud?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC
    driver-class-name: com.mysql.jdbc.Driver
    username: root
    password: root
  devtools:
    restart:
      enabled: true

mybatis:
  type-aliases-package: com.atjianyi.entites #配置别名
  mapper-locations: classpath:com/atjianyi/mapper/xml/*.xml #配置mapper映射文件
  configuration:
    map-underscore-to-camel-case: true #配置文件

eureka:
  client:
    register-with-eureka: true
    fetch-registry: true
    service-url:
      defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka
# 注册测服务名称相同
server:
  port: 8002
spring:
  application:
    name: cloud-pri-service
  datasource:
    url: jdbc:mysql://localhost:3306/springcloud?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC
    driver-class-name: com.mysql.jdbc.Driver
    username: root
    password: root
  devtools:
    restart:
      enabled: true

mybatis:
  type-aliases-package: com.atjianyi.entites #配置别名
  mapper-locations: classpath:com/atjianyi/mapper/xml/*.xml #配置mapper映射文件
  configuration:
    map-underscore-to-camel-case: true #配置文件

eureka:
  client:
    register-with-eureka: true
    fetch-registry: true
    service-url:
      defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka
     #添加主机名称
   instance:
     instance-id: payment8002
     prefer-ip-address: true #显示IP
```

3. 启动服务，就可以访问eureka服务查看注册微服务。

![image-20221113095323466](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221113095323466.png)

4. 调用者根据服务名称在服务注册中心获取IP和地址。
   - 开启负载均衡

![image-20221113101725178](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221113101725178.png)

![image-20221113101520457](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221113101520457.png)

---

## 3. 服务发现

   当我们想Eureka服务注册信息后，我们可以通过服务发现，来获取某个微服务的具体信息。

> 将自身微服务信息，暴露出去。

### 使用

1. 在主类中，开启服务发现

```java
@SpringBootApplication
@ComponentScan("com.atjianyi.*")
@EnableDiscoveryClient //开启服务发现
@EnableEurekaClient
public class PaymentApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentApplication.class);
    }
}
```

2. 编写一个方法用于获取

```java
 @GetMapping("getdis")
    public R getdis(){
        return R.ok().data("data",discoveryClient.getInstances("CLOUD-PRI-SERVICE"));
    }
```

![image-20221113210358184](C:\Users\JaneOnly\AppData\Roaming\Typora\typora-user-images\image-20221113210358184.png)



> 然而eureka已经停止更新了，不用学了 hhhh
